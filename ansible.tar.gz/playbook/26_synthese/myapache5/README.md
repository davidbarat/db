Role Name
=========

Rôle de deploiement apache sur une centos ou Debian

Répertoire privé protégé par mot de passe demandé à l'utilisateur

Requirements
------------

None

Role Variables
--------------

Voir fichier vars/main.yml

Dependencies
------------

None

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { myapache }

License
-------

BSD

Author Information
------------------

Thomas Constans <thomas@opendoor.fr>
