Role Name
=========

Rôle de deploiement apache sur une centos.

1 seul vhost par machine


Requirements
------------

None

Role Variables
--------------

http_port: 80

Hosts Variables:
---------------

servername: orsys.fr
serveralias: "www.orsys.fr"
documentroot: /var/www/html/orsys.fr
accesslog: /var/log/httpd/access_orsys.fr_log
errorlog: /var/log/httpd/error_orsys.fr_log

Dependencies
------------

None

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { myapache }

License
-------

BSD

Author Information
------------------

Thomas Constans <thomas@opendoor.fr>
